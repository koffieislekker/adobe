module.exports = {
    campaign: {
        campaignClientID : "d2c09ac767024e39ad463c6194169520",
        campaignClientSecret : "59d287ae-b51d-45ac-9892-09b6f8fc025c",
        campaignOrgID : "B5BA1225524F6CEC0A490D4D@AdobeOrg",
        campaignTechnicalAccount : "D79B36525AA4FAF00A495C6C@techacct.adobe.com",
        campaignPEM : "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQC9+rttNI6DKsuM\nOMv+Wlu2t48xZkqXmNxvK5Jix+FLUSeReL8qZVo+z5N0vyM48k+/r7z4iOzsXyTJ\nZ6RqprTXMY3Rz7fMRoSyddSug/zmRGnpZUzry9oRIdN/qX4s51CAy2B/gjF18id/\nNU7hOyTtlWoyeUWBzkKB6pNcboay8pvC7pm64LESH9xVhiIXpQqnlKV7EQRJ3TOm\nCmZuylwp8nXIlwQW7KkeDji5javvSHorizrnBOPFbraQUuOGnXAl5I8vKny/WPvq\nNH4cn+LzLKyFDiVojGR6maChv/ozBVF8XM582C5AVtu39fkE4mtRd79u72yfyLgI\n3sp9ZC+bAgMBAAECggEAXro01oEMRm8CS4rOfKdFb9gbOECPFQQNdgk91q9fsRRo\nLGsOtu8Ojp8mIWJlB7Ia/bN9AFgV+s5+I0bgfqVdKqf01RdDyEGpTOrf/5ykb5TR\nUqVGM5TTyRMayF8VIQK961p9ZVbfnrX957oG+Ntq0GReLYi2lcDo/Kqgi8g4teTQ\nvFAc3zV1ZPEwam0U+PgYlLuYrtwQlcdoX/1tyXKYK2g/wohiWPIZczMD88oWfMUw\n+/Y1kt5dSNgkiwIhDXO2+VbhRClFH3/U42gEognI0hkl4emfnnzGTeu8MahXNox9\nGD8i4hPvor6PPG1CSbFZYEFnN+0U0eKP7FiyedFEQQKBgQD8npmIC/KJU1wLc1Xr\nbz/28NXGRjnIv1MSdmBDNAZ9MqeR2vUYgxotIN+PWOJS7Y3DXAX5fNCPy1q6NxFG\n4rEUm5NiPV3g7uZyGPL+JHb3EXKZgM54KP4D0N5FYbDzveZVhhsVmDKzFBGMNmv4\neptax7lNFgyNaofcyY9jVF9u8QKBgQDAhYu5vnRo780gtxbqEnGBWi1uHGiO1WrK\n2CkA4Nvkn0Qo3Imcubg8vh1i7YZOaI+pB4Y/CmETIhE/pkZr5n2g1O3t82yty40v\nx3jOx3XYQCiIuOOtf4KOxMJH46j8+KwT4Zq9OUNWvUrjd5oGYHpmfvlQyqJAR5L5\nXqw2xfefSwKBgHZn6FKqNu5DEjuTvcvygyq9y5V5yQ/dDZTzwz78naYFHiHxXTw2\nBwjsBZ1s7fgsvGu7MFm2NRORH190/DYbfyDHoxdC6EPL9lu4cfzJHrHDjdGBXEVa\nAWXMesJOfeBhPBsOFpfSlMD3QRpVT9pRrYupXaNSGGQYcMH9/6VxIKIhAoGAE2Nf\nlu0fPBIqTkkh/aCt3aD/Qj+KKBhGEPeD6Zq7imKfsp3DHg12CGf8/aF+DRdqoFMp\nqd+ZtxuPMSHFpcgojrHi5DvHjhkZtt4XxHtB2u1bJ6m3BBn7Q/V8u1CqDA/fBIGL\n29KQfYPCrvW0hT/iE8Bly0Uc4exTWNm37iwxq9ECgYBeiJezNbBwS3nm3d9+PgNV\npUx1gszQ9lvRWNxsGZ3J4wgi9+znv454o9FxoqmqYdJmGDzNx5AWu3Y4BWGCevZ+\nmKJUo5azpz/KhniiAWe3XfExsG+wGB6sF7FpqvjTuzwyDGf45R9dwABDsiJeNd9x\nZq4pwHUhBIWIk6V+Cp1eUw==\n-----END PRIVATE KEY-----",
        campaignIMSEndpoint : "https://ims-na1.adobelogin.com/s/ent_campaign_sdk"
    },
    target: {
        targetTenant : "adobeinternalpburg",
        targetClientID : "73c2d9702f954e9197128be313e6dd63",
        targetClientSecret : "955788bd-12c4-4cd5-82fd-d7edc6bca483",
        targetOrgID : "E118E1CE5444D9E40A4C98A5@AdobeOrg",
        targetTechnicalAccount : "c099b7ae-8b89-47d2-b342-87731de3417f@techacct.adobe.com",
        targetPEM : "-----BEGIN RSA PRIVATE KEY-----\nMIIEpQIBAAKCAQEAq9cKmhgz2ICYeAUwzpnZ/X73o1p3lsew2Wj6x5PYIhpOoE2Z\n2cro6IVgCNHbbttoBWjUrL5h2GTBElTOQbYFh2Qr7WVclMXFuQ0ZjhmN1lIsSv5o\naCSqy6kqeINOMes17nz6CNNWK4XyDxCUJzDucA/jDpsZRBoeb2HyQZ+/oxvaA2xs\nvrOLPFltBusNpwvln+8CgYEApti87esDEPv4NfM9npXZTa+rYgXUO5hPMJwz\n+J5hmTktXQ1FuntqgDwtKtQti/oo8agMLU3g4WYS0yiIQgHEnmiFQ8m976IU7k+4\nnLUwftkwORrtKNxFjONPsLEwQgLFh2fozB2K0sqCarmym85IMxflpGxJv/fUAFWX\nJPfU5NMCgYEA13Q6+fVv/RC5o/Y0/KUOJBfQaR33u91OTPQJLlHm7yInw7zjTabN\nZqiV/t2X0YLAYiHi6zEqTldJVJSwZ+WZVtTeNRr2IxE6m5nla1JKj+oBlDK02idI\nyleyND+XMLrNwnIqRPJ0Vqkwguk9nFHizBTxzGCsfYMeEwp9ZEAOs1E=\n-----END RSA PRIVATE KEY-----",
        targetIMSEndpoint : "https://ims-na1.adobelogin.com/s/ent_marketing_sdk"
    }
}





    